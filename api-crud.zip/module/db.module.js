const mongoose = require("mongoose")
mongoose.connect('mongodb+srv://admin:hlonKDpJiHMQWiBG@trp.vpwpbca.mongodb.net/users')
module.exports = mongoose